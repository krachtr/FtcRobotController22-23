public class MyFIRSTJavaOpMode {
}
